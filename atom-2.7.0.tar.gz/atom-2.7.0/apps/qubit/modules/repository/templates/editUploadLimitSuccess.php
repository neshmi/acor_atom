<?php

include_component('repository', 'uploadLimit', ['resource' => $resource, 'noedit' => true]);
