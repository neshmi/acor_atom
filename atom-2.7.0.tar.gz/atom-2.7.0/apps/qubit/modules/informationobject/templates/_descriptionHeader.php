<h1><?php echo $levelOfDescriptionAndIdentifier; ?><?php if (!empty($levelOfDescriptionAndIdentifier)) { ?> - <?php } ?><?php echo render_title($title); ?></h1>
