<?php

echo get_partial('term/format', ['resource' => $resource]);
